--\\ Checks --
local getscriptbytecode = getscriptbytecode or warn('ERROR LEVEL 3 : Missing exploit function (getscriptbytecode)')
local decompile = decompile or warn('ERROR LEVEL 3 : Missing exploit function (decompile)')


--\\ Vars

local _function = {}

--\\ Collectors --
if type(getgenv().data_collector) ~= "table" then -- check if already defined the table so we dont accidently reset it
getgenv().data_collector = {}

getgenv().garbage_collector = {}
end


--\\ Functions --
_function.traceline = function(a, b) -- prints line useful for trace hook getting the full line of a script
    for line in a:gmatch("([^\n]*)") do
        if line:match(b) then
            return line
        end
    end
    return nil
end
_function.trace_arguments = function(a)
    local comma_count = 0 
    for _ in a:gmatch(",") do
        comma_count = comma_count + 1
    end
    if comma_count > 0 then
        comma_count = comma_count + 1 -- + 1 because args is more than comma
    end
    return comma_count
end
_function.hookevent = function(params)
    local remote = params.path --\\ <path>
    local type = params.type --\\ <string>
    local argum = params.arguments --\\ <table> or <string>
    local callback = params.callback
    local connection
    local debounce = false
    local blocked = {}
    if remote and type then
        if type == "spy" then
            connection = remote.OnClientEvent:Connect(function(...)
                local args = {...}
                callback(args)
            end)
        elseif type == "block" then
            blocked[remote] = remote.Name
            getgenv().data_collector[remote] = remote.Name
            remote.Name = "vortex_blocked_119/144/122/442/111/01/01/02/01/01"
            callback(remote.Name)
        elseif type == "unblock" then
            remote.Name = blocked[remote]
            callback(remote.Name)
        elseif type == "callback" then
            connection = remote.OnClientEvent:Connect(function(...)
                if debounce then -- debounce so we dont go on infinite loop (onclientevent)
                    debounce = false
                    remote:FireServer(unpack(argum))
                    callback(argum)
                    debounce = true
                end
            end)
        elseif type == "trace" then 
            print('ran 1')
            if argum == "local" then
                print('ran')
                for _,v in ipairs(game.Players.LocalPlayer:GetDescendants()) do
                    if v:IsA('LocalScript') then
                        print('Dumping : ' .. v.Name)
                        local script = decompile(v)
                        print('Simulating and running script : ' .. v.Name)
                        if _function.traceline(script, remote.Name) then
                            local args_traced = _function.trace_arguments(_function.traceline(script, remote.Name))
                            callback("-- TRACED AND SCRIPT DUMP SUCCESSFUL LOGS: --")
                            callback("- Remote path: game." .. remote:GetFullName())
                            callback("- Script path: game." .. v:GetFullName())
                            callback("- Arguments amount (OnClientEvent hook): " .. args_traced)
                            callback("- Script line: " .. _function.traceline(script, remote.Name))
                            --callback("- Script dump: " .. script)
                        end
                    end
                end
                if game.Players.LocalPlayer.Character then
                for _,v in ipairs(game.Players.LocalPlayer.Character:GetDescendants()) do
                    if v:IsA('LocalScript') then
                        print('Dumping : ' .. v.Name)
                        local script = decompile(v)
                        print('Simulating and running script : ' .. v.Name)
                        if _function.traceline(script, remote.Name) then
                            local args_traced = _function.trace_arguments(_function.traceline(script, remote.Name))
                            callback("-- TRACED AND SCRIPT DUMP SUCCESSFUL LOGS: --")
                            callback("- Remote path: game." .. remote:GetFullName())
                            callback("- Script path: game." .. v:GetFullName())
                            callback("- Arguments amount (OnClientEvent hook): " .. args_traced)
                            callback("- Script line: " .. _function.traceline(script, remote.Name))
                            --callback("- Script dump: " .. script)
                        end
                    end
                end
            end
            end
        end
    end
    return connection
end
_function.hookvalue = function(type)
    if type == "nil" then
        return -math.huge --// Useful when idfk never used it really LMFAO
    elseif type == "nan" then
        return 0/0 --// Useful when fucking up a remote event
    elseif type == "overflow" then
        return 9.2^319.83667  --// Useful for integer overflow? and break server code
    end
    return 0
end

return _function
